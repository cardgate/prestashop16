<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgateideal}prestashop>cardgateideal_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgateideal}prestashop>cardgateideal_fc4cf10b1c13f74f48fe46ae45a876d2'] = 'CardGate iDEAL';
$_MODULE['<{cardgateideal}prestashop>cardgateideal_a6de38ba0dadab7ace162e0056e692da'] = 'Accepteert betalingen met CardGate iDEAL';
$_MODULE['<{cardgateideal}prestashop>cardgateideal_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgateideal}prestashop>cardgateideal_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
$_MODULE['<{cardgateideal}prestashop>cardgateideal_f736d3fa0c1e64bbcb34c744395f9cf9'] = '-Kies uw bank a.u.b.-';
$_MODULE['<{cardgateideal}prestashop>payment_execution_054087b8dd723bf676c50a0b8f848f7a'] = 'iDEAL betaling';
$_MODULE['<{cardgateideal}prestashop>payment_execution_f1d3b424cd68795ecaa552883759aceb'] = 'Order samenvatting';
$_MODULE['<{cardgateideal}prestashop>payment_execution_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgateideal}prestashop>payment_execution_cea8e024a84187b840d60fbac80e9701'] = 'U heeft iDEAL als betaalmethode gekozen';
$_MODULE['<{cardgateideal}prestashop>payment_execution_3491e4b5dab480539a1a5485a2e689cb'] = 'Kies uw bank:';
$_MODULE['<{cardgateideal}prestashop>payment_execution_569fd05bdafa1712c4f6be5b153b8418'] = 'Andere betaalmethoden';
$_MODULE['<{cardgateideal}prestashop>payment_execution_46b9e3665f187c739c55983f757ccda0'] = 'Ik bevesting mijn Order';
$_MODULE['<{cardgateideal}prestashop>payment_execution_64d452459a2ed47b25fc16efbfb0048d'] = 'Kies uw bank!';
