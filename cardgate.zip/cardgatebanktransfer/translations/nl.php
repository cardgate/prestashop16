<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgatebanktransfer}prestashop>cardgatebanktransfer_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgatebanktransfer}prestashop>cardgatebanktransfer_37ddc7966a1bff8442934d7e6ea57e44'] = 'CardGate Bankoverboeking';
$_MODULE['<{cardgatebanktransfer}prestashop>cardgatebanktransfer_bea25c2020005443b91186324b5ca867'] = 'Accepteert betalingen met CardGate Bankoverboeking';
$_MODULE['<{cardgatebanktransfer}prestashop>cardgatebanktransfer_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgatebanktransfer}prestashop>cardgatebanktransfer_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
