<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgatepaypal}prestashop>cardgatepaypal_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgatepaypal}prestashop>cardgatepaypal_4596565a10d46adcd43df0256f8d9bbf'] = 'CardGate PayPal';
$_MODULE['<{cardgatepaypal}prestashop>cardgatepaypal_f769a78d5c5950700f7640a86cc95058'] = 'Accepteert betalingen met CardGate PayPal';
$_MODULE['<{cardgatepaypal}prestashop>cardgatepaypal_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgatepaypal}prestashop>cardgatepaypal_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
