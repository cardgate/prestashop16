<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgatedirectdebit}prestashop>cardgatedirectdebit_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgatedirectdebit}prestashop>cardgatedirectdebit_529837bcd541032b108b8026081c7df9'] = 'CardGate DirectDebit';
$_MODULE['<{cardgatedirectdebit}prestashop>cardgatedirectdebit_827a0aae97fe30c59d8dd9a87c2e6aef'] = 'Accepteert betalingen met CardGate  DirectDebit';
$_MODULE['<{cardgatedirectdebit}prestashop>cardgatedirectdebit_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgatedirectdebit}prestashop>cardgatedirectdebit_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
