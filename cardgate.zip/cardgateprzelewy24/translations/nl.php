<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgateprzelewy24}prestashop>cardgateprzelewy24_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgateprzelewy24}prestashop>cardgateprzelewy24_8d2ec3016fe137a565eabd05542bc7b9'] = 'CardGate Przelewy24';
$_MODULE['<{cardgateprzelewy24}prestashop>cardgateprzelewy24_e941e8d233532dc19bb2542fae3f5aef'] = 'Accepteert betalingen met CardGate Przelewy24';
$_MODULE['<{cardgateprzelewy24}prestashop>cardgateprzelewy24_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgateprzelewy24}prestashop>cardgateprzelewy24_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
