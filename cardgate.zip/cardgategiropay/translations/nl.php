<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cardgategiropay}prestashop>cardgategiropay_da9c72b9e543135f3f59e3c8ac68ef35'] = 'Betaal met';
$_MODULE['<{cardgategiropay}prestashop>cardgategiropay_c6595881e4de8ffbafefed1eb1491479'] = 'CardGate Giropay';
$_MODULE['<{cardgategiropay}prestashop>cardgategiropay_29ad3a89f3bbaa5522c505f2629c699a'] = 'Accepteert betalingen met CardGate Giropay';
$_MODULE['<{cardgategiropay}prestashop>cardgategiropay_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Weet u zeker dat u uw details wilt verwijderen?';
$_MODULE['<{cardgategiropay}prestashop>cardgategiropay_59ca7aaff7f6bfd9dd776a6add44770f'] = 'De CardGate module is niet gevonden';
